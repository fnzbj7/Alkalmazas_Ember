QUnit.module('JSHint - .');
QUnit.test('app.js should pass jshint', function(assert) { 
  assert.ok(true, 'app.js should pass jshint.'); 
});
